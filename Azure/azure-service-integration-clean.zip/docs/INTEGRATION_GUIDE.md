# Integration guide

`backend/app/providers/azure` is provider code; `backend/app/api/routes.py` and `frontend/` are the development shell. The receiving platform supplies authenticated user identity, database lifecycle, secret management, gateway/CORS, and production OAuth state/session behavior.

Microsoft authentication is not platform authentication. Microsoft tokens authorize ARM calls; the platform session identifies the owner. Never return provider tokens to the browser. Install the backend dependencies, apply migration `0002_azure_connections`, include the router, and replace `platform_user()` with the platform principal. Preserve ownership filters and encrypted token storage.

Configure the exact callback, client credentials, tenant, scope, and encryption key. The API routes are documented in [API_REFERENCE.md](API_REFERENCE.md). Test denied consent, expired state, revoked access, empty subscriptions, ARM resources, and billing denial with a developer tenant. Real Azure verification was not possible in this workspace.
