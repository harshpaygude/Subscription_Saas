# Architecture

```mermaid
flowchart LR
 UI[React UI] --> API[FastAPI API]
 API --> AUTH[Entra OAuth + PKCE]
 API --> DB[(PostgreSQL)]
 API --> ARM[Azure Resource Manager]
 API --> COST[Cost Management]
```

OAuth state is one-time and expires after ten minutes. The code exchange is server-side with PKCE. The token response is Fernet-encrypted before persistence; the key is external configuration. ARM clients use backend-only bearer tokens, timeouts, pagination, and safe error mapping. Connections and subscriptions are scoped to a platform user. The development header identity must be replaced before production.
