# Architecture

```mermaid
flowchart LR
 UI[React UI] --> API[FastAPI API]
 API --> AUTH[Entra OAuth + PKCE]
 API --> DB[(PostgreSQL)]
 API --> ARM[Azure Resource Manager]
 API --> COST[Cost Management]
```

OAuth state is stored as a hash in PostgreSQL, expires after ten minutes, is consumed before exchange, and is bound to an HttpOnly SameSite cookie. The code exchange is server-side with PKCE. The token response is Fernet-encrypted before persistence; the key is external configuration. Expired access tokens are refreshed server-side when possible. ARM clients use backend-only bearer tokens, timeouts, pagination, and safe error mapping. Connections and subscriptions are scoped to a platform user. The development header identity must be replaced before production.
