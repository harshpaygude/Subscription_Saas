"""Microsoft Azure provider integration."""
