# Azure integration handoff

This package contains the Azure provider, FastAPI development shell, React UI, migration, configuration template, tests, and documentation. It is implemented but not verified against a real Azure tenant.

Read [README.md](README.md), then [docs/AZURE_ACCOUNT_SETUP.md](docs/AZURE_ACCOUNT_SETUP.md), [docs/INTEGRATION_GUIDE.md](docs/INTEGRATION_GUIDE.md), and [docs/API_REFERENCE.md](docs/API_REFERENCE.md). Supply a real Entra app, exact callback URI, server-side secret/certificate, encryption key, PostgreSQL, and the receiving platform's user identity. Replace the development `X-Platform-User-ID` fallback before deployment. Real login, billing, renewal, and multi-worker state remain unverified or require integration hardening.
