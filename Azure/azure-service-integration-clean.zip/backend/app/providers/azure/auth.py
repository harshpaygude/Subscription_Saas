from datetime import datetime, timedelta, timezone
from typing import Any

import httpx

from app.core.config import Settings
from app.providers.azure.security import authorization_url, new_state, pkce_pair


class OAuthError(RuntimeError):
    pass


class OAuthService:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.pending: dict[str, tuple[str, datetime, str]] = {}

    def begin(self, user_id: str) -> str:
        if not self.settings.azure_client_id:
            raise OAuthError("Azure OAuth is not configured")
        state = new_state()
        verifier, challenge = pkce_pair()
        self.pending[state] = (user_id, datetime.now(timezone.utc) + timedelta(minutes=10), verifier)
        return authorization_url(self.settings.azure_tenant, self.settings.azure_client_id, self.settings.azure_redirect_uri, state, challenge, self.settings.azure_scopes)

    def redeem(self, state: str, code: str) -> tuple[str, dict[str, Any]]:
        pending = self.pending.pop(state, None)
        if not pending or pending[1] < datetime.now(timezone.utc):
            raise OAuthError("Invalid or expired OAuth state")
        if not code:
            raise OAuthError("Microsoft did not return an authorization code")
        data = {"client_id": self.settings.azure_client_id, "client_secret": self.settings.azure_client_secret, "grant_type": "authorization_code", "code": code, "redirect_uri": self.settings.azure_redirect_uri, "scope": self.settings.azure_scopes, "code_verifier": pending[2]}
        try:
            response = httpx.post(f"https://login.microsoftonline.com/{self.settings.azure_tenant}/oauth2/v2.0/token", data=data, timeout=20)
        except httpx.HTTPError as exc:
            raise OAuthError("Microsoft token exchange failed") from exc
        if response.status_code >= 400:
            raise OAuthError("Microsoft token exchange was rejected")
        payload = response.json()
        if not payload.get("access_token"):
            raise OAuthError("Microsoft token response did not contain an access token")
        return pending[0], payload
