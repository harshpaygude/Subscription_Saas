# Changelog

## 2026-10-16

Added Entra authorization-code + PKCE, encrypted token storage, ARM/Cost clients, Azure models and migration `0002_azure_connections`, discovery/selection/resource/cost/status/disconnect routes, Azure UI, and integration documentation.
