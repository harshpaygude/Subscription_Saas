# API reference

Development authentication uses `X-Platform-User-ID`; production must use the receiving platform session. Errors use `{"detail":"..."}`.

| Method | Route | Purpose |
|---|---|---|
| GET | `/api/providers` | Provider metadata |
| GET | `/api/azure/oauth/start` | Microsoft redirect |
| GET | `/api/azure/oauth/callback?code=...&state=...` | One-time callback |
| GET | `/api/azure/connection` | Current connection status |
| POST | `/api/azure/subscriptions/discover` | Discover subscriptions |
| POST | `/api/azure/subscriptions` | Body `{ "subscription_ids": ["sub-id"] }`; verify and save selection |
| GET | `/api/azure/subscriptions/{id}/resources` | ARM inventory |
| GET | `/api/azure/subscriptions/{id}/cost?start=2026-01-01&end=2026-02-01` | Actual daily cost query |
| DELETE | `/api/azure/connection` | Disconnect and delete token cache |

All routes are user-scoped. Dates are ISO dates with `start < end`; ARM list calls follow `nextLink`. Resource data is read-only. Planned: metrics beyond Cost Management, per-subscription disconnect, durable background refresh, and tenant enumeration UI.
